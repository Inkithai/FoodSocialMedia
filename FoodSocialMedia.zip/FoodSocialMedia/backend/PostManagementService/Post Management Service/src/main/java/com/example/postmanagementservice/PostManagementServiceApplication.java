package com.example.postmanagementservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PostManagementServiceApplication {

    public static void main(String[] args) {
        SpringApplication.run(PostManagementServiceApplication.class, args);
    }

}
