package com.example.InteractionManagementService;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class InteractionManagementServiceApplication {

    public static void main(String[] args) {
        SpringApplication.run(InteractionManagementServiceApplication.class, args);
    }

}
