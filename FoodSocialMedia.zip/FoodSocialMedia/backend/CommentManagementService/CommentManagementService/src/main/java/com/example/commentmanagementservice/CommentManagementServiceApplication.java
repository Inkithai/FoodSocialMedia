package com.example.commentmanagementservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CommentManagementServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(CommentManagementServiceApplication.class, args);
	}

}
